#ifndef _CATCH_LINE_
#define _CATCH_LINE_
#include "HardwareInfo.c"
#include "line_time.c"
#include <GetLightSensorThreshold.h>
#include "goline.c"
#include <SetInBeep.h>
#include <SetWaitForTime.h>
#include "speed_control.c"

void catch_line(int sp, int light_w)
{
    // extern global var
    extern unsigned int S1;
    extern unsigned int S2;
    extern unsigned int S3;
    extern unsigned int S4;
    extern unsigned int S5;
    extern long light_ws;

    unsigned int G1 = 0;
    unsigned int G5 = 0;
    line_time(sp, 200);
    G1 = GetLightSensorThreshold(_P1_);
    GetLightSensorThreshold(_P5_);
    if ( light_w==15 )
    {
        while (1)
        {
            goline(sp);
            if ( S1<G1&&S5<G5 )
            {
                break;
            }
        }
    }
    else
    {
        if ( light_w==1 )
        {
            while (1)
            {
                goline(sp);
                if ( S1<G1 )
                {
                    break;
                }
            }
        }
        else
        {
            if ( light_w==5 )
            {
                while (1)
                {
                    goline(sp);
                    if ( S5<G1 )
                    {
                        break;
                    }
                }
            }
            else
            {
                while (1)
                {
                    goline(sp);
                    if ( S5<G5||S5<G5 )
                    {
                        break;
                    }
                }
            }
        }
    }
    SetInBeep(ON);
    SetWaitForTime(0.05);
    SetInBeep(OFF);
    speed_control(0, 0);
}
#endif

