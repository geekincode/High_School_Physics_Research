#ifndef _TURN_W_
#define _TURN_W_
#include "HardwareInfo.c"
#include "speed_control.c"
#include <GetLightSensorThreshold.h>
#include "light01.c"

void turn_w(int spl, int spr, int whi)
{
    // extern global var
    extern unsigned int S1;
    extern unsigned int S2;
    extern unsigned int S3;
    extern unsigned int S4;
    extern unsigned int S5;

    unsigned int G1 = 0;
    unsigned int G2 = 0;
    unsigned int G3 = 0;
    unsigned int G4 = 0;
    unsigned int G5 = 0;
    speed_control(spl, spr);
    G1 = GetLightSensorThreshold(_P1_);
    G2 = GetLightSensorThreshold(_P2_);
    G3 = GetLightSensorThreshold(_P3_);
    G4 = GetLightSensorThreshold(_P4_);
    G5 = GetLightSensorThreshold(_P5_);
    while (1)
    {
        light01();
        if ( whi==1 )
        {
            if ( S1<G1 )
            {
                break;
            }
        }
        else
        {
            if ( whi==2 )
            {
                if ( S2<G2 )
                {
                    break;
                }
            }
            else
            {
                if ( whi==3 )
                {
                    if ( S3<G3 )
                    {
                        break;
                    }
                }
                else
                {
                    if ( whi==4 )
                    {
                        if ( S4<G4 )
                        {
                            break;
                        }
                    }
                    else
                    {
                        if ( whi==5 )
                        {
                            if ( S5<G5 )
                            {
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    speed_control(0, 0);
}
#endif

