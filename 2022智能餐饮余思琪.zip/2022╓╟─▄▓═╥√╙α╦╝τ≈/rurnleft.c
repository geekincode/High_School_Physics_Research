#ifndef _RURNLEFT_
#define _RURNLEFT_
#include "HardwareInfo.c"
#include "go_bmp.c"
#include "turn_w.c"

void rurnleft()
{
    go_bmp(50, 50);
    turn_w(-30, 30, 1);
    turn_w(-25, 25, 3);
}
#endif

