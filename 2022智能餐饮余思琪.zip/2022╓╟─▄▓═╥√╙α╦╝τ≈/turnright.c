#ifndef _TURNRIGHT_
#define _TURNRIGHT_
#include "HardwareInfo.c"
#include "go_bmp.c"
#include "turn_w.c"

void turnright()
{
    go_bmp(50, 110);
    turn_w(30, -30, 5);
    turn_w(25, -25, 3);
}
#endif

