#ifndef _GET_QR_
#define _GET_QR_
#include "HardwareInfo.c"
#include <GetScanCamera.h>
#include <SetDisplayVar.h>
#include "turn_o.c"
#include "turn_w.c"
#include "line_bmp.c"
#include "catch_line.c"
#include "rurnleft.c"
#include "turnright.c"
#include <SetMotorServo.h>
#include <SetWaitForTime.h>
#include "go_bmp.c"
#include "turn_angle.c"
#include <SetServo.h>

void Get_QR()
{
    long var0 = 0;
    while (1)
    {
        var0 = GetScanCamera();
        if ( var0!=999 )
        {
            SetDisplayVar(1, var0, YELLOW, BLACK);
            if ( var0==3 )
            {
                turn_o(100, -50, 50);
                turn_w(-50, 50, 3);
                line_bmp(50, 150);
                catch_line(50, 5);
                rurnleft();
                catch_line(50, 1);
                turnright();
                catch_line(50, 1);
                SetMotorServo(_M3_, -20, 230);
                SetWaitForTime(1);
                go_bmp(-50, 200);
                turn_angle(50, 200);
                turn_w(50, -50, 3);
                catch_line(50, 1);
                rurnleft();
                catch_line(50, 1);
                go_bmp(50, 100);
                catch_line(50, 1);
                go_bmp(50, 100);
                catch_line(50, 1);
                go_bmp(50, 300);
                break;
            }
            else
            {
                if ( var0==2 )
                {
                    turn_o(100, 50, -50);
                    turn_w(50, -50, 3);
                    line_bmp(50, 150);
                    catch_line(50, 1);
                    turnright();
                    catch_line(50, 5);
                    turnright();
                    catch_line(50, 1);
                    go_bmp(50, 100);
                    SetMotorServo(_M3_, -20, 230);
                    SetWaitForTime(1);
                    go_bmp(-50, 200);
                    turn_angle(50, 200);
                    turn_w(50, -50, 3);
                    catch_line(50, 1);
                    rurnleft();
                    catch_line(50, 1);
                    break;
                }
                else
                {
                    if ( var0==1 )
                    {
                        go_bmp(-50, 200);
                        rurnleft();
                        catch_line(50, 1);
                        catch_line(50, 1);
                        catch_line(50, 1);
                        turn_w(-25, 30, 3);
                        catch_line(30, 5);
                        turn_angle(50, 200);
                        go_bmp(50, 300);
                        SetWaitForTime(0.5);
                        SetServo(_P1_, 50);
                        SetWaitForTime(0.5);
                        go_bmp(-50, 400);
                        turn_angle(50, 150);
                        turn_w(30, -25, 3);
                        catch_line(50, 5);
                        turnright();
                        catch_line(50, 1);
                        rurnleft();
                        catch_line(50, 1);
                        turnright();
                        catch_line(50, 1);
                        catch_line(50, 1);
                        go_bmp(50, 500);
                        break;
                    }
                }
            }
        }
    }
}
#endif

