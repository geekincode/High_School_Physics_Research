#ifndef _GOLINE_
#define _GOLINE_
#include "HardwareInfo.c"
#include <GetSysTime.h>
#include "light01.c"
#include <GetLightSensorThreshold.h>
#include "speed_control.c"

void goline(int sp)
{
    // extern global var
    extern unsigned int S1;
    extern unsigned int S2;
    extern unsigned int S3;
    extern unsigned int S4;
    extern unsigned int S5;
    extern unsigned int g_temp;
    extern double line_proportion;   //Ѳ�߶���
    extern long T15;
    extern long light_ws;

    int spl = 0;
    int spr = 0;
    long var0 = 0;
    long vt = 200;
    unsigned int G1 = 0;
    unsigned int G2 = 0;
    unsigned int G3 = 0;
    unsigned int G4 = 0;
    unsigned int G5 = 0;
    var0 = GetSysTime();
    //��ȡ���״̬
    light01();
    G1 = GetLightSensorThreshold(_P1_);
    G2 = GetLightSensorThreshold(_P2_);
    G3 = GetLightSensorThreshold(_P3_);
    G4 = GetLightSensorThreshold(_P4_);
    G5 = GetLightSensorThreshold(_P5_);
    if ( S1<G1 )
    {
        g_temp=1;
        T15 = GetSysTime();
    }
    else
    {
        if ( S5<G1 )
        {
            g_temp=5;
            T15 = GetSysTime();
        }
    }
    if ( S3<G3 )
    {
        spl=sp;
        spr=sp;
        if ( var0-T15>=vt )
        {
            g_temp=3;
        }
        if ( light_ws==1 )
        {
            spl=sp*line_proportion;
            spr=sp;
        }
        if ( light_ws==5 )
        {
            spl=sp;
            spr=sp*line_proportion;
        }
    }
    else
    {
        if ( S2<G2 )
        {
            spl=sp*line_proportion;
            spr=sp;
            if ( var0-T15>=vt )
            {
                g_temp=2;
            }
        }
        else
        {
            if ( S4<G4 )
            {
                spl=sp;
                spr=sp*line_proportion;
                if ( var0-T15>=vt )
                {
                    g_temp=4;
                }
            }
            else
            {
                if ( S1<G1 )
                {
                    spl=-40;
                    spr=50;
                }
                else
                {
                    if ( S5<G5 )
                    {
                        spl=50;
                        spr=-40;
                    }
                    else
                    {
                        if ( g_temp==1 )
                        {
                            spl=-55;
                            spr=45;
                        }
                        else
                        {
                            if ( g_temp==5 )
                            {
                                spl=45;
                                spr=-55;
                            }
                            else
                            {
                                if ( g_temp==2 )
                                {
                                    spl=sp*0.8;
                                    spr=sp;
                                }
                                else
                                {
                                    if ( g_temp==4 )
                                    {
                                        spl=sp;
                                        spr=sp*0.8;
                                    }
                                    else
                                    {
                                        if ( g_temp==3 )
                                        {
                                            spl=sp;
                                            spr=sp;
                                        }
                                        else
                                        {
                                            spl=sp;
                                            spr=sp;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    speed_control(spl, spr);
}
#endif

