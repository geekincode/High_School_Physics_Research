#ifndef _LINECOLOR_
#define _LINECOLOR_
#include "HardwareInfo.c"

void LineColor(int color)
{
    // extern global var
    extern int mode;

    mode=color;
}
#endif

